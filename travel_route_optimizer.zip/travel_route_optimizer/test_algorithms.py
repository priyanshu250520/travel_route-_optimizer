import unittest
from graph import Graph, sample_graph
from algorithms import dijkstra, a_star


class TestRouting(unittest.TestCase):
    def setUp(self):
        self.g = sample_graph()

    def test_sample_route(self):
        for algo in (dijkstra, a_star):
            path, total, _ = algo(self.g, "A", "E")
            self.assertEqual(path, ["A", "C", "B", "D", "E"])
            self.assertEqual(total, 10)

    def test_same_source_and_destination(self):
        for algo in (dijkstra, a_star):
            path, total, _ = algo(self.g, "C", "C")
            self.assertEqual((path, total), (["C"], 0))

    def test_unreachable(self):
        g = Graph()
        g.add_city("X", 0, 0)
        g.add_city("Y", 5, 5)
        for algo in (dijkstra, a_star):
            self.assertEqual(algo(g, "X", "Y")[0], [])

    def test_heuristic_never_overestimates(self):
        for a in self.g.cities():
            for b, w in self.g.neighbours(a):
                self.assertLessEqual(self.g.heuristic(a, b), w)

    def test_both_algorithms_agree_everywhere(self):
        for s in self.g.cities():
            for d in self.g.cities():
                self.assertEqual(dijkstra(self.g, s, d)[1], a_star(self.g, s, d)[1])


if __name__ == "__main__":
    unittest.main()
