# Travel Route Optimizer

Design & Analysis of Algorithms (5.0CE100COIH) - Project Based Learning

Finds the shortest route between two locations using **Dijkstra's Algorithm** and the
**A\* Algorithm**, both driven by a **priority queue** (Python `heapq`).

## Files
| File | Purpose |
|---|---|
| `graph.py` | Graph class (cities = vertices, roads = weighted edges) and the sample graph |
| `algorithms.py` | `dijkstra()` and `a_star()` with path reconstruction |
| `main.py` | Console application |
| `test_algorithms.py` | Unit tests |

## Run
Requires Python 3.8+ (no extra libraries).

    python main.py
    python -m unittest -v

## Sample run
    Enter Source Location: A
    Enter Destination Location: E
    Shortest Route: A -> C -> B -> D -> E
    Total Distance: 10 km

## How it works
1. **Graph representation** - adjacency dictionary, undirected weighted edges.
2. **Dijkstra** - pops the node with the smallest distance from the source.
3. **A\*** - pops the node with the smallest `g + h`, where `h` is the straight-line
   distance to the destination (never over-estimates, so the result is optimal).
4. **Path reconstruction** - previous-node links are followed back from the destination.

Time complexity with a binary heap: O((V + E) log V).

## Team
Priyanshu (1/24/SET/BCS/243), Charan (1/24/SET/BCS/244),
Rakesh (1/24/SET/BCS/242), Aditya (1/24/SET/BCS/226)
Faculty: Dr. Nitasha Soni
