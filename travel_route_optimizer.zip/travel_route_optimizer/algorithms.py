"""Dijkstra's and A* shortest-path algorithms using a priority queue (heapq)."""
import heapq


def _rebuild_path(previous, source, destination):
    """Path reconstruction: walk the previous-node links back from the destination."""
    path, node = [], destination
    while node is not None:
        path.append(node)
        node = previous.get(node)
    path.reverse()
    return path if path and path[0] == source else []


def dijkstra(graph, source, destination):
    """Return (path, total_distance, nodes_expanded). Empty path if unreachable."""
    dist = {c: float("inf") for c in graph.cities()}
    previous = {source: None}
    dist[source] = 0
    pq = [(0, source)]          # priority queue ordered by distance from source
    expanded = 0
    done = set()
    while pq:
        d, node = heapq.heappop(pq)
        if node in done:
            continue
        done.add(node)
        expanded += 1
        if node == destination:
            break
        for nxt, w in graph.neighbours(node):
            nd = d + w
            if nd < dist[nxt]:
                dist[nxt] = nd
                previous[nxt] = node
                heapq.heappush(pq, (nd, nxt))
    path = _rebuild_path(previous, source, destination)
    return path, (dist[destination] if path else float("inf")), expanded


def a_star(graph, source, destination):
    """Return (path, total_distance, nodes_expanded). Empty path if unreachable.

    Priority = g (actual cost so far) + h (straight-line estimate to destination).
    """
    g_cost = {c: float("inf") for c in graph.cities()}
    previous = {source: None}
    g_cost[source] = 0
    pq = [(graph.heuristic(source, destination), source)]
    expanded = 0
    done = set()
    while pq:
        _, node = heapq.heappop(pq)
        if node in done:
            continue
        done.add(node)
        expanded += 1
        if node == destination:
            break
        for nxt, w in graph.neighbours(node):
            ng = g_cost[node] + w
            if ng < g_cost[nxt]:
                g_cost[nxt] = ng
                previous[nxt] = node
                heapq.heappush(pq, (ng + graph.heuristic(nxt, destination), nxt))
    path = _rebuild_path(previous, source, destination)
    return path, (g_cost[destination] if path else float("inf")), expanded
