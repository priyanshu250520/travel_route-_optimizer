const map = L.map('map').setView([28.6139, 77.2090], 11);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

let routeLayer = null;
let markers = [];
const form = document.getElementById('routeForm');
const stopsList = document.getElementById('stopsList');
const message = document.getElementById('message');
const results = document.getElementById('results');
const planButton = document.getElementById('planButton');

document.getElementById('addStop').addEventListener('click', () => {
  if (stopsList.querySelectorAll('input').length >= 8) {
    showMessage('You can add up to 8 destinations.', 'error');
    return;
  }
  const input = document.createElement('input');
  input.type = 'text';
  input.className = 'stop-input';
  input.placeholder = 'Enter another destination';
  stopsList.appendChild(input);
});

function showMessage(text, type = '') {
  message.textContent = text;
  message.className = 'message ' + type;
}

async function geocode(place) {
  const url = `https://nominatim.openstreetmap.org/search?format=json&limit=1&q=${encodeURIComponent(place)}`;
  const response = await fetch(url, { headers: { 'Accept': 'application/json' } });
  if (!response.ok) throw new Error('Location lookup is temporarily unavailable.');
  const data = await response.json();
  if (!data.length) throw new Error(`Could not find: ${place}. Try a more specific place or city.`);
  return { name: place, lat: Number(data[0].lat), lon: Number(data[0].lon) };
}

function distance(a, b) {
  const rad = value => value * Math.PI / 180;
  const dLat = rad(b.lat - a.lat), dLon = rad(b.lon - a.lon);
  const x = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLon / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
}

function orderStops(start, stops) {
  const remaining = [...stops];
  const ordered = [];
  let current = start;
  while (remaining.length) {
    let bestIndex = 0;
    for (let i = 1; i < remaining.length; i++) {
      if (distance(current, remaining[i]) < distance(current, remaining[bestIndex])) bestIndex = i;
    }
    current = remaining.splice(bestIndex, 1)[0];
    ordered.push(current);
  }
  return ordered;
}

async function getRoute(points, mode) {
  const profile = mode === 'walking' ? 'foot' : mode === 'cycling' ? 'bike' : 'driving';
  const coords = points.map(p => `${p.lon},${p.lat}`).join(';');
  const url = `https://router.project-osrm.org/route/v1/${profile}/${coords}?overview=full&geometries=geojson`;
  const response = await fetch(url);
  if (!response.ok) throw new Error('Could not calculate the route. Please try again.');
  const data = await response.json();
  if (data.code !== 'Ok' || !data.routes.length) throw new Error('No route was found for these locations.');
  return data.routes[0];
}

form.addEventListener('submit', async event => {
  event.preventDefault();
  const startText = document.getElementById('start').value.trim();
  const stopTexts = [...stopsList.querySelectorAll('input')].map(input => input.value.trim()).filter(Boolean);
  if (!startText || !stopTexts.length) {
    showMessage('Enter a starting location and at least one destination.', 'error');
    return;
  }

  planButton.disabled = true;
  planButton.textContent = 'Finding your route...';
  results.classList.add('hidden');
  showMessage('Looking up locations and arranging your stops. Please wait...');

  try {
    const locations = await Promise.all([startText, ...stopTexts].map(geocode));
    const start = locations[0];
    const ordered = orderStops(start, locations.slice(1));
    const points = [start, ...ordered];
    const route = await getRoute(points, document.getElementById('travelMode').value);

    if (routeLayer) map.removeLayer(routeLayer);
    markers.forEach(marker => map.removeLayer(marker));
    markers = [];

    routeLayer = L.geoJSON(route.geometry, {
      style: { color: '#2864e8', weight: 5, opacity: 0.85 }
    }).addTo(map);

    points.forEach((point, index) => {
      const marker = L.marker([point.lat, point.lon]).addTo(map);
      marker.bindPopup(`<strong>${index === 0 ? 'Start' : `Stop ${index}`}</strong><br>${escapeHtml(point.name)}`);
      markers.push(marker);
    });

    map.fitBounds(routeLayer.getBounds(), { padding: [35, 35] });
    document.getElementById('distance').textContent = `${(route.distance / 1000).toFixed(1)} km`;
    document.getElementById('duration').textContent = formatDuration(route.duration);
    const list = document.getElementById('routeList');
    list.innerHTML = '';
    points.forEach((point, index) => {
      const li = document.createElement('li');
      li.textContent = `${index === 0 ? 'Start' : `Stop ${index}`}: ${point.name}`;
      list.appendChild(li);
    });
    results.classList.remove('hidden');
    showMessage('Your route is ready. The stops are arranged using a nearest-stop planning method.', 'success');
  } catch (error) {
    showMessage(error.message || 'Something went wrong. Please check your locations and try again.', 'error');
  } finally {
    planButton.disabled = false;
    planButton.innerHTML = 'Optimize my route <span>→</span>';
  }
});

function formatDuration(seconds) {
  const minutes = Math.round(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const remainder = minutes % 60;
  return hours ? `${hours} hr ${remainder} min` : `${remainder} min`;
}

function escapeHtml(value) {
  return value.replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'
  })[char]);
}
