# RouteWise — Travel Route Optimizer

A responsive travel route optimizer website built with HTML, CSS, and JavaScript.

## Features
- Enter a starting location and multiple destinations
- Add up to 8 destinations
- Arrange stops using a nearest-stop planning method
- View the suggested route on an interactive map
- See estimated distance and travel time
- Driving, cycling, and walking route profiles
- Responsive layout for desktop and mobile

## How to run
1. Extract the ZIP file.
2. Open the `travel_route_optimizer` folder.
3. Open `index.html` in a modern browser.
4. Enter a starting location and at least one destination, then select **Optimize my route**.

An active internet connection is required. The website uses OpenStreetMap tiles, Nominatim geocoding, Leaflet, and the public OSRM routing demo service. Public services may have usage limits or temporary downtime.

## Project structure
- `index.html` — website layout
- `css/style.css` — styling and responsive design
- `js/app.js` — location search, stop ordering, route lookup, and map display

## Note
The stop ordering uses a nearest-stop heuristic. It is a practical approximation and does not guarantee the mathematically shortest possible multi-stop route.
