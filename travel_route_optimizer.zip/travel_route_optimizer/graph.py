"""Graph data structure for the Travel Route Optimizer.

Cities are vertices and roads are weighted, undirected edges.
Each city also has (x, y) coordinates in km, used only by A* to
estimate the remaining distance (the heuristic).
"""
import math


class Graph:
    def __init__(self):
        self.adj = {}      # city -> {neighbour: distance}
        self.coords = {}   # city -> (x, y)

    def add_city(self, name, x, y):
        self.adj.setdefault(name, {})
        self.coords[name] = (x, y)

    def add_road(self, a, b, distance):
        if a not in self.adj or b not in self.adj:
            raise ValueError("Both cities must be added before a road.")
        if distance < 0:
            raise ValueError("Dijkstra's and A* need non-negative distances.")
        self.adj[a][b] = distance
        self.adj[b][a] = distance

    def cities(self):
        return sorted(self.adj)

    def neighbours(self, city):
        return self.adj[city].items()

    def heuristic(self, a, b):
        """Straight-line distance between two cities (never over-estimates)."""
        (x1, y1), (x2, y2) = self.coords[a], self.coords[b]
        return math.hypot(x1 - x2, y1 - y2)


def sample_graph():
    """The sample graph used in the report and presentation."""
    g = Graph()
    for name, x, y in [("A", 0, 0), ("B", 2, 1), ("C", 2, 0), ("D", 7, 1), ("E", 9, 1)]:
        g.add_city(name, x, y)
    for a, b, d in [("A", "B", 4), ("A", "C", 2), ("B", "C", 1), ("B", "D", 5),
                    ("C", "D", 8), ("C", "E", 10), ("D", "E", 2)]:
        g.add_road(a, b, d)
    return g
