"""Travel Route Optimizer - console application.

Run:  python main.py
"""
from graph import sample_graph
from algorithms import dijkstra, a_star

LINE = "-" * 40


def ask_city(prompt, graph):
    while True:
        city = input(prompt).strip().upper()
        if city in graph.cities():
            return city
        print("  Unknown location. Choose from:", ", ".join(graph.cities()))


def show(title, result):
    path, total, expanded = result
    print(f"\n{title}")
    if not path:
        print("  No route found.")
        return
    print("  Shortest Route:", " -> ".join(path))
    print(f"  Total Distance: {total:g} km")
    print(f"  Nodes explored: {expanded}")


def main():
    graph = sample_graph()
    print(LINE)
    print("       TRAVEL ROUTE OPTIMIZER")
    print(LINE)
    print("Available Locations:", ", ".join(graph.cities()))
    print()
    while True:
        src = ask_city("Enter Source Location: ", graph)
        dst = ask_city("Enter Destination Location: ", graph)
        print("\nCalculating Shortest Route...")
        show("Dijkstra's Algorithm", dijkstra(graph, src, dst))
        show("A* Algorithm", a_star(graph, src, dst))
        print("\nRoute Calculation Completed!")
        print(LINE)
        if input("Find another route? (y/n): ").strip().lower() != "y":
            break
        print()


if __name__ == "__main__":
    main()
